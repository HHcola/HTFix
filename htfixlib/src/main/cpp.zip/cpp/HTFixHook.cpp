//
// Created by timothyhe on 2019/7/8.
//
#include <jni.h>
#include "base/base.h"
#include "hook/MethodHook.h"
extern "C" int SDK_INT = 0;
extern "C" bool DEBUG = false;

static HTFix::MethodHook methodHook;
extern "C"
JNIEXPORT jint JNICALL
Java_com_htfixlib_HTFixNative_hookMethod(JNIEnv *env, jclass type, jobject originMethod,
                                            jobject hookMethod) {
    return methodHook.doHookMethod(originMethod, hookMethod);
}
