//
// Created by timothyhe on 2019/7/10.
//

#include "ArtMethodOffSet.h"

namespace HTFix {
    void ArtMethodOffSet::setArtMethodOffSet(jint sdkVersion) {
        SDKVersion = sdkVersion;
        LOGI("init to SDK %d", sdkVersion);
        switch (sdkVersion) {
            case __ANDROID_API_P__:
                kAccCompileDontBother = 0x02000000;
                artmethod_in_object = 0;
                access_flags_in_artMethod = 4;
                //dex_method_index_in_artMethod = 4*3;
                entry_point_from_quick_compiled_code_in_artMethod =
                        roundUpToPtrSize(4 * 4 + 2 * 2) + pointer_size;
                size_artmethod = roundUpToPtrSize(4 * 4 + 2 * 2) + pointer_size * 2;
                break;
            case __ANDROID_API_O_MR1__:
                kAccCompileDontBother = 0x02000000;
            case __ANDROID_API_O__:
                artmethod_in_object = 0;
                access_flags_in_artMethod = 4;
                dex_method_index_in_artMethod = 4 * 3;
                dex_cache_resolved_methods_in_artMethod = roundUpToPtrSize(4 * 4 + 2 * 2);
                array_in_pointerarray = 0;
                entry_point_from_quick_compiled_code_in_artMethod =
                        roundUpToPtrSize(4 * 4 + 2 * 2) + pointer_size * 2;
                size_artmethod = roundUpToPtrSize(4 * 4 + 2 * 2) + pointer_size * 3;
                break;
            case __ANDROID_API_N_MR1__:
            case __ANDROID_API_N__:
                artmethod_in_object = 0;
                access_flags_in_artMethod = 4; // sizeof(GcRoot<mirror::Class>) = 4
                dex_method_index_in_artMethod = 4 * 3;
                dex_cache_resolved_methods_in_artMethod = roundUpToPtrSize(4 * 4 + 2 * 2);
                array_in_pointerarray = 0;

                // ptr_sized_fields_ is rounded up to pointer_size in ArtMethod
                entry_point_from_quick_compiled_code_in_artMethod =
                        roundUpToPtrSize(4 * 4 + 2 * 2) + pointer_size * 3;

                size_artmethod = roundUpToPtrSize(4 * 4 + 2 * 2) + pointer_size * 4;
                break;
            case __ANDROID_API_M__:
                artmethod_in_object = 0;
                entry_point_from_interpreter_in_artMethod = roundUpToPtrSize(4 * 7);
                entry_point_from_quick_compiled_code_in_artMethod =
                        entry_point_from_interpreter_in_artMethod + pointer_size * 2;
                dex_method_index_in_artMethod = 4 * 5;
                dex_cache_resolved_methods_in_artMethod = 4;
                array_in_pointerarray = 4 * 3;
                size_artmethod = roundUpToPtrSize(4 * 7) + pointer_size * 3;
                break;
            case __ANDROID_API_L_MR1__:
                artmethod_in_object = 4 * 2;
                entry_point_from_interpreter_in_artMethod = roundUpToPtrSize(
                        artmethod_in_object + 4 * 7);
                entry_point_from_quick_compiled_code_in_artMethod =
                        entry_point_from_interpreter_in_artMethod + pointer_size * 2;
                dex_method_index_in_artMethod = artmethod_in_object + 4 * 5;
                dex_cache_resolved_methods_in_artMethod = artmethod_in_object + 4;
                array_in_pointerarray = 12;
                size_artmethod = entry_point_from_interpreter_in_artMethod + pointer_size * 3;
                break;
            case __ANDROID_API_L__:
                artmethod_in_object = 4 * 2;
                entry_point_from_interpreter_in_artMethod = artmethod_in_object + 4 * 4;
                entry_point_from_quick_compiled_code_in_artMethod =
                        entry_point_from_interpreter_in_artMethod + 8 * 2;
                dex_method_index_in_artMethod =
                        artmethod_in_object + 4 * 4 + 8 * 4 + 4 * 2;
                dex_cache_resolved_methods_in_artMethod = artmethod_in_object + 4;
                array_in_pointerarray = 12;
                size_artmethod = artmethod_in_object + 4 * 4 + 8 * 4 + 4 * 4;
                break;
            default:
                LOGE("not compatible with SDK %d", sdkVersion);
                break;
        }

        setupTrampoline(entry_point_from_interpreter_in_artMethod);
    }

    void ArtMethodOffSet::setNonCompilable(void *method) {
        if (SDKVersion < __ANDROID_API_N__) {
            return;
        }
        int access_flags = read32((char *) method + access_flags_in_artMethod);
        LOGI("setNonCompilable: access flags is 0x%x", access_flags);
        access_flags |= kAccCompileDontBother;
        memcpy(
                (char *) method + access_flags_in_artMethod,
                &access_flags,
                4
        );
    }

    void ArtMethodOffSet::setupTrampoline(int entry_point_from_quick_compiled_code_in_artMethod) {
        setupTrampoline(entry_point_from_quick_compiled_code_in_artMethod);
    }

    void *ArtMethodOffSet::genTrampoline(void *hookMethod) {
        return genTrampoline(hookMethod);
    }
}
