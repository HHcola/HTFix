//
// Created by timothyhe on 2019/7/10.
//

#ifndef HTFIX_ARTMETHODOFFSET_H
#define HTFIX_ARTMETHODOFFSET_H

#include "../base/base.h"
#include "../trampoline/trampoline.h"

namespace HTFix {
    enum Version {
        __ANDROID_API_L__ = 21,
        __ANDROID_API_L_MR1__,
        __ANDROID_API_M__,
        __ANDROID_API_N__,
        __ANDROID_API_N_MR1__,
        __ANDROID_API_O__,  // Android 8.0
        __ANDROID_API_O_MR1__, // Android 8.1
        __ANDROID_API_P__ // Android 9.0
    };

    class ArtMethodOffSet{
    public:
        void setArtMethodOffSet(jint sdkVersion);
        void setNonCompilable(void *method);
        void setupTrampoline(int entry_point_from_quick_compiled_code_in_artMethod);
        void *genTrampoline(void *hookMethod);
    public:
        int entry_point_from_interpreter_in_artMethod;
        int entry_point_from_quick_compiled_code_in_artMethod;
        int dex_method_index_in_artMethod;
        int dex_cache_resolved_methods_in_artMethod;
        int array_in_pointerarray;
        int artmethod_in_object;
        int access_flags_in_artMethod;
        size_t size_artmethod;
        int kAccNative = 0x0100;
        int kAccCompileDontBother = 0x01000000;
        size_t kDexCacheMethodCacheSize = 1024;
        int SDKVersion;
    };
}
#endif //HTFIX_ARTMETHODOFFSET_H
