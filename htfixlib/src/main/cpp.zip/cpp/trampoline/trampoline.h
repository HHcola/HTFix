//
// Created by timothyhe on 2019/7/11.
//

#ifndef HTFIX_TRAMPOLINE_H
#define HTFIX_TRAMPOLINE_H
namespace HTFix {
    class Trampoline {
    public:
        Trampoline();
        int doInitHookCap(unsigned int cap);
        void setupTrampoline(int entry_point_from_quick_compiled_code_in_artMethod);
        void *genTrampoline(void *hookMethod);
    public:
        unsigned int hookCap; // capacity for trampolines
        unsigned int hookCount; // current count of used trampolines
        unsigned char trampoline[12];
        unsigned char *trampolineCode; // place where trampolines are saved
        unsigned int trampolineSize; // trampoline size required for each hook
    };
}
#endif //HTFIX_TRAMPOLINE_H
