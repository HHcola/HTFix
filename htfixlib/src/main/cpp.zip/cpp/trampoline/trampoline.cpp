//
// Created by timothyhe on 2019/7/11.
//

#include <sys/mman.h>
#include <string.h>
#include <errno.h>
#include "trampoline.h"
#include "../base/base.h"
namespace HTFix {
    int Trampoline::doInitHookCap(unsigned int cap) {
        if (cap == 0) {
            LOGE("invalid capacity: %d", cap);
            return 1;
        }
        if (hookCap) {
            LOGW("allocating new space for trampoline code");
        }
        unsigned int allSize = trampolineSize * cap;
        unsigned char *buf = static_cast<unsigned char *>(mmap(NULL, allSize,
                                                               PROT_READ | PROT_WRITE | PROT_EXEC,
                                                               MAP_ANON | MAP_PRIVATE, -1, 0));
        if (buf == MAP_FAILED) {
            LOGE("mmap failed, errno = %s", strerror(errno));
            return 1;
        }
        hookCap = cap;
        hookCount = 0;
        trampolineCode = buf;
        return 0;
    }

    void Trampoline::setupTrampoline(int entry_point_from_quick_compiled_code_in_artMethod) {
#if defined(__i386__)
        trampoline[7] = (unsigned char) entry_point_from_quick_compiled_code_in_artMethod;
#elif defined(__x86_64__)
        trampoline[12] = (unsigned char)entry_point_from_quick_compiled_code_in_artMethod;
#elif defined(__arm__)
        trampoline[4] = (unsigned char)entry_point_from_quick_compiled_code_in_artMethod;
#elif defined(__aarch64__)
        trampoline[5] |=
            ((unsigned char) entry_point_from_quick_compiled_code_in_artMethod) << 4;
    trampoline[6] |=
            ((unsigned char) entry_point_from_quick_compiled_code_in_artMethod) >> 4;
#else
#error Unsupported architecture
#endif
    }

    void *Trampoline::genTrampoline(void *hookMethod) {
        void *targetAddr;

        targetAddr = trampolineCode + trampolineSize * hookCount;
        memcpy(targetAddr, trampoline,
               sizeof(trampoline)); // do not use trampolineSize since it's a rounded size

        // replace with the actual ArtMethod addr
#if defined(__i386__)
        memcpy(targetAddr + 1, &hookMethod, pointer_size);

#elif defined(__x86_64__)
        memcpy((char*)targetAddr + 2, &hookMethod, pointer_size);

#elif defined(__arm__)
        memcpy(targetAddr+8, &hookMethod, pointer_size);

#elif defined(__aarch64__)
        memcpy(targetAddr + 12, &hookMethod, pointer_size);

#else
#error Unsupported architecture
#endif

        return targetAddr;
    }

    Trampoline::Trampoline() {
/// 00 00 9F E5 ; ldr r0, [pc, #0]
// 20 F0 90 E5 ; ldr pc, [r0, 0x20]
// 78 56 34 12 ; 0x12345678 (addr of the hook method)
        trampoline = {
                0x00, 0x00, 0x9f, 0xe5,
                0x20, 0xf0, 0x90, 0xe5,
                0x78, 0x56, 0x34, 0x12
        };

        trampolineSize = roundUpToPtrSize(sizeof(trampoline));
    }

}
