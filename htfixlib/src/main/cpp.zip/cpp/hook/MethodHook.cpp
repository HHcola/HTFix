//
// Created by timothyhe on 2019/7/11.
//

#include <malloc.h>
#include "MethodHook.h"

namespace HTFix {

    int MethodHook::doHookMethod(void *targetMethod, void *hookMethod) {

        // set kAccCompileDontBother for a method we do not want the compiler to compile
        // so that we don't need to worry about hotness_count_
        if (artMethodOffSet.SDKVersion >= __ANDROID_API_N__) {
            artMethodOffSet.setNonCompilable(targetMethod);
            artMethodOffSet.setNonCompilable(hookMethod);
        }

        void *newEntrypoint = artMethodOffSet.genTrampoline(hookMethod);

        if (newEntrypoint) {
            memcpy((char *) targetMethod + artMethodOffSet.entry_point_from_interpreter_in_artMethod,
                   &newEntrypoint,
                   pointer_size);
        } else {
            LOGE("failed to allocate space for trampoline of target method");
            return 1;
        }

        if (artMethodOffSet.entry_point_from_interpreter_in_artMethod != 0) {
            memcpy((char *) targetMethod + artMethodOffSet.entry_point_from_interpreter_in_artMethod,
                   (char *) hookMethod + artMethodOffSet.entry_point_from_interpreter_in_artMethod,
                   pointer_size);
        }

        // set the target method to native so that Android O wouldn't invoke it with interpreter
        if (artMethodOffSet.SDKVersion >= __ANDROID_API_O__) {
            int access_flags = read32((char *) targetMethod + artMethodOffSet.access_flags_in_artMethod);
            access_flags |= artMethodOffSet.kAccNative;
            memcpy(
                    (char *) targetMethod + artMethodOffSet.access_flags_in_artMethod,
                    &access_flags,
                    4
            );
            LOGI("access flags is 0x%x", access_flags);
        }

        return 0;
    }

    void MethodHook::ensureMethodCached(void *hookMethod) {
//        if (artMethodOffSet.SDKVersion <= __ANDROID_API_O_MR1__) {
//            // update the cached method manually
//            // first we find the array of cached methods
//            void *dexCacheResolvedMethods = (void *) readAddr(
//                    (void *) ((char *) hookMethod +
//                            artMethodOffSet.dex_cache_resolved_methods_in_artMethod));
//            // then we get the dex method index of the static backup method
//            unsigned int methodIndex = read32(
//                    (void *) ((char *) hookMethod + artMethodOffSet.dex_method_index_in_artMethod));
//
//            // finally the addr of backup method is put at the corresponding location in cached methods array
//            if (artMethodOffSet.SDKVersion == __ANDROID_API_O_MR1__) {
//                // https://github.com/rk700/YAHFA/issues/91
//                // for Android 8.1, the MethodDexCacheType array is of limited size
//                // the remainder of method index mod array size is used for indexing
//                size_t slotIndex = methodIndex % kDexCacheMethodCacheSize;
//                LOGI("method index is %d, slot index id %zd", methodIndex, slotIndex);
//                // any element could be overwritten since the array is of limited size
//                // so just malloc a new buffer used as cached methods array for hookMethod to resolve backupMethod
//                void *newCachedMethodsArray = calloc(kDexCacheMethodCacheSize, pointer_size * 2);
//                // the 0th entry of the array has method index as 1
//                unsigned int one = 1;
//                memcpy(newCachedMethodsArray + pointer_size, &one, 4);
//
//                // update the backupMethod addr in cached methods array
//                memcpy(newCachedMethodsArray + pointer_size * 2 * slotIndex,
//                       (&backupMethod),
//                       pointer_size
//                );
//
//                // use the new buffer as cached methods array for hookMethod
//                memcpy(((char *) hookMethod) + artMethodOffSet.dex_cache_resolved_methods_in_artMethod,
//                       (&newCachedMethodsArray),
//                       pointer_size);
//
//            } else {
//                memcpy((char *) dexCacheResolvedMethods + artMethodOffSet.array_in_pointerarray +
//                       pointer_size * methodIndex,
//                       (&backupMethod),
//                       pointer_size);
//            }
//        }
    }
}